LIFE SIM — ASSET PACK PATCH (your models + Kenney kits in the game)
===================================================================

WHAT CHANGED
  client/src/scenes/assetModels.tsx   NEW  model loader (falls back to the old shapes if a file is missing)
  client/src/scenes/City.tsx          main avenues use Kenney road tiles; shop + apartment landmarks and tall/low
                                      procedural buildings use your store/apartment GLBs; trees are Kenney
                                      trees/palms; park gets bushes, flowers, rocks
  client/src/scenes/LivingCity.tsx    traffic uses real cars (Kenney car kit + your sedan; taxi; delivery truck as bus)
  client/src/scenes/HomeFurniture.tsx home furniture uses Kenney furniture models (bed, sofa, TV, fridge, stove,
                                      shower, lamp, desk+PC+chair, dining table+chairs, bookshelf)
  client/public/models/world/**       the model files (about 2.5 MB) + KENNEY-LICENSE.txt (CC0)

HOW TO DEPLOY (same as the upgrade patch)
  1) From your repo root:  unzip -o life-sim-assets-patch.zip
     (files land in client/src/scenes and client/public/models/world)
  2) git add -A && git commit -m "Use asset pack for city, cars, trees, furniture" && git push origin main
  3) Netlify rebuilds the client. No server / Railway change is needed.
  4) Hard refresh the game (Ctrl+Shift+R).

IF SOMETHING LOOKS OFF (one-line fixes)
  - Cars drive backwards:         LivingCity.tsx  ->  VEHICLE_YAW = Math.PI
  - Buildings face the wrong way: City.tsx        ->  BUILDING_YAW = Math.PI
  - Avenue tiles look wrong:      City.tsx        ->  delete the <InstancedTiles .../> line (old roads come back)
  - Any model that fails to load automatically shows the original box version.

NOT DONE
  - Running.fbx: your avatar already has its own Run animation and a custom bone/IK system. Re-targeting a Mixamo
    clip needs visual testing, so it was left out. Say the word and I'll do it as an opt-in test.
  - Your road-straight-01.glb is included at models/world/roads/road-straight-01-user.glb but not used yet.
  - These changes could not be built or viewed in this workspace (package registry unreachable), so please check
    the Netlify deploy preview before relying on it.
