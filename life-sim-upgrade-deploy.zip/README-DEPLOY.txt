LIFE SIM — UPGRADE PATCH (map, night, goals, minimap, CEO business, characters)
================================================================================

WHAT IS IN THIS ZIP
-------------------
client/  → browser game (Netlify)
server/  → multiplayer API (Railway)

New files (must stay in these paths):
  client/src/components/StarterGoals.tsx
  client/src/components/Minimap.tsx
  client/src/components/NearbyPlayers.tsx
  client/src/components/WorldEventBanner.tsx

Changed files (overwrite your copies):
  client/src/scenes/City.tsx
  client/src/scenes/Environment.tsx
  client/src/scenes/LivingCity.tsx
  client/src/scenes/Interior.tsx
  client/src/scenes/World.tsx
  client/src/scenes/Player.tsx
  client/src/scenes/OtherPlayer.tsx
  client/src/scenes/Avatar.tsx
  client/src/scenes/RiggedAvatar.tsx
  client/src/components/HUD.tsx
  client/src/components/CharacterCreate.tsx
  client/src/components/phone/apps/JobsApp.tsx
  client/src/components/phone/apps/InventoryApp.tsx
  client/src/components/phone/apps/BusinessApp.tsx
  client/src/components/phone/apps/HomeApp.tsx
  server/prisma/seedJobsAndTravel.ts
  server/src/game/business/businessService.ts

STEP-BY-STEP DEPLOY
===================

1) Open your Life-sim repo in Codespaces (or local clone).

2) Download this zip to your computer, then upload into Codespaces:
   - Drag the zip into the Codespaces file tree, OR
   - Terminal: put the zip in /tmp then unzip (see step 3).

3) From the REPO ROOT (folder that contains client/ and server/), run:

   unzip -o /path/to/life-sim-upgrade-deploy.zip -d /tmp/life-sim-patch
   # copy files into the repo (keeps folder structure)
   cp -R /tmp/life-sim-patch/client/* client/ 2>/dev/null || true
   cp -R /tmp/life-sim-patch/server/* server/ 2>/dev/null || true

   # Safer explicit copy from the extracted tree:
   cd /tmp/life-sim-patch
   find client server -type f | while read f; do
     mkdir -p "/workspaces/YOUR_REPO_NAME/$(dirname "$f")"
     cp "$f" "/workspaces/YOUR_REPO_NAME/$f"
   done

   Replace YOUR_REPO_NAME with your actual Codespaces folder name
   (e.g. Life-sim-game). Or run from repo root:

   cd /workspaces/Life-sim-game   # adjust name
   unzip -o ~/life-sim-upgrade-deploy.zip
   # if zip root contains client/ and server/, files land correctly:
   # if nested, use: unzip -o zip -d /tmp/p && cp -a /tmp/p/client/. client/ && cp -a /tmp/p/server/. server/

4) Commit and push:

   git add -A
   git status
   git commit -m "Upgrade: map variants, night, traffic, starter goals, minimap, CEO business, characters"
   git push origin main

5) Wait for builds:
   - Netlify: https://app.netlify.com/projects/life-sim-game-vubl
   - Railway: project "life-sim" → service "game-server" (must rebuild from Git, not only Redeploy)

6) After Railway is live, optional travel seed (if Travel app is empty):

   # In Railway shell for game-server, or one-off:
   npm run db:seed
   # or: npx tsx prisma/seedJobsAndTravel.ts
   # (use the seed command your package.json defines)

7) Open the game:
   https://life-sim-game-vubl.netlify.app

   Hard refresh (Ctrl+Shift+R) so the new client loads.

CHECKLIST AFTER DEPLOY
----------------------
[ ] Night is not pure black
[ ] Starter goals panel bottom-left
[ ] Minimap bottom-right
[ ] Nearby players top-right
[ ] Phone → Business → open Shop/Company → Hire as CEO
[ ] Character create has shirt/pants styles
[ ] Travel routes list options (after seed)

NOTES
-----
- VITE_SERVER_URL on Netlify must be: https://game-server-production-9342.up.railway.app
  (no trailing slash)
- Server changes only apply after Railway builds from the new Git commit.
